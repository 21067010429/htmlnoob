package PACK3;

public class 数组S5E9 {
    public static void main(String[] args) {
        double[] arr = new double[3];

        System.out.println(arr);
        System.out.println(arr[0]);
        System.out.println(arr[1]);
        System.out.println(arr[2]);
    }
}
