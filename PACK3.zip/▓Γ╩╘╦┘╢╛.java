package PACK3;

public class 测试速毒 {
    public static void main(String[] args) {
        System.out.println("速度一半");
    }
}
