package PACK3;

public class S4E2M2 {
    public static void main(String[] args) {
        int a =  0 , b = 0;
        while (b <= 5){
            a += b;
            b++;
        }
        System.out.println(a);
    }
}
