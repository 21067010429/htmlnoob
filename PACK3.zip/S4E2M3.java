package PACK3;

public class S4E2M3 {
    public static void main(String[] args) {
        int h = 1 , n = 0 ;//*珠峰*10
        while (h < 88444300){
            h *= 2;
            n++;
        }
        System.out.println(n);
    }
}
