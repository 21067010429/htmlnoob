package PACK3;

public class PTA测试 {
    /*
    public static void main(String[] args) {
        int x = 4;
        System.out.println("value is" + ((x > 4)?(int)99.9:9));
    }
    */
    /*
    public static void main(String[] args) {
        int i = 6;
         i += i - 1;
        System.out.println(i);
    }
     */
    /*
    public static void main(String[] args) {
        System.out.println("How\nare\nyou!\n");
    }

     */
    /*
    public static void main(String[] args) {
        int a,b,c;
        a = 1;
        b = 3;
        c = (a + b > 3? ++a:b++);
        System.out.println(a + " " + b + " " + c);
    }

     */
    /*
    public static void main(String[] args) {
        int a = 5;
        a = a + 10;
        a = a+10；
        System.out.println(a);
    }

     */
    /*
    public static void main(String[] args) {
        int c = 'c'/3;
        //二进制 0110 0011	ASCII 99	十六进制 63	图形 c
        System.out.println(c);
    }

     */
    /*
    public static void main(String[] args) {
        int x = 7,y = 8,z = 9;
        char ch = 'A';
        x++;z--;
        System.out.println(x==y);
        System.out.println(y=z--);
        System.out.println(x==z);
        //System.out.println(z);
        System.out.println(ch++ == 'A');
        System.out.println(ch++ == 'B');
        System.out.println(ch);
    }

     */
    /*
    public static void main(String[] args) {
        int x = 3,y = 4;
        boolean b;
        //++x;
        b = x < y || ++x == --y;
        System.out.println(b +" " + x + " " + y);
    }

     */
    /*
    public static void main(String[] args) {
        int x = 5;
        double y = 10.5f;
        float z = (float) (x * y);
        System.out.println(z);
    }

     */
    /*
    public static void main(String[] args) {
        int a = 748;
        int 百位 = a / 100;
        int 十位 = a / 10 % 10;
        int 个位 = a % 10;
        System.out.println(十位);
    }

     */
    /*
    public static void main(String[] args) {
        boolean b1 = true,b2 = true,b3 = false;
        boolean b = !b1 && b2 || b3;
        System.out.println(b);

    }
    */
    public static void main(String[] args) {
        int a = 10;
        int i , j;
        i = ++ a;
        System.out.println(a);
        System.out.println(i);
        j = a --;
        System.out.println(a);
        System.out.println(i);
        System.out.println(j);
    }
}
