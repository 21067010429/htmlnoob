package PACK3;

public class S4E2M5 {
    public static void main(String[] args) {
        int a = 0;
        for (int i = 1;i <= 5;i++){
            a += i;
        }
        System.out.println(a);
    }
}
